Jura was designed by Daniel Johnson.  Please send any bug reports or glyph requests
to il.basso.buffo@gmail.com.

The glyphs in the Kayah Li range (U+A900 - U+A92F) are licensed under the GNU Public
License, version 3.  These glyphs are also included in FreeMono, which is part of
the GNU FreeFont project (http://www.gnu.org/software/freefont/).

All other glyphs in this font are licensed under the Open Font License.

You should have received a copy of both these licenses bundled with the font. If you
did not receive them, you may find them at the following URLs:

http://scripts.sil.org/OFL
http://www.gnu.org/licenses/gpl.txt